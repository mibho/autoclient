import numpy as np
import cv2 as cv

import BotTools
from ROICoords import cScanCoords as coords
from Constants import *
from BotTools import cBotTools
from BotData import cBotData
import gamestatus as gs

class cBotFunctionsTools(cBotTools, cBotData):
    def __init__(self, pID, windowName, clientNum, deviceObj, adbSockInfo):
        cBotTools.__init__(self, pID, windowName, clientNum, deviceObj, adbSockInfo)
        cBotData.__init__(self)
        self.gameState = gs.GameStatus()
        self.level30 = False
        self.level60 = False
        self.level90 = False
        self.currChar = 0
        self.totalChars = 0
        self.dailyDone = { 0 : False,
                           1 : False,
                           2 : False,
                           3 : False,
                           4 : False,
                           5 : False,
                           6 : False,

        }
        self.dataGrabbed = False
        self.afkStart = 0
        self.timerStarted = False

        #findTemplateMatch2
    def scanWindow2(self, temp, threshold):
        self.preClickImg = self.returnColorSS(False)
        w2, h2 = temp.shape[::-1]
        res = cv.matchTemplate(self.preClickImg ,temp, eval('cv.TM_CCOEFF_NORMED')) #cv.TM_CCOEFF_NORMED
        
        loc = np.where( res >= threshold)
    
        if np.amax(res) > threshold:
            for pt in zip(*loc[::-1]):
                self.matchCoords.setPoints(pt[0], pt[1])    
            return True
        else:
            return False
    
        #by default it grabs gray ROIs
    def scanThisROI2(self, temp, y1,y2,x1,x2 ,threshold, ptsneeded):
        filteredPic = self.checkForPopups()
        if not self.popupDetected:
            roi = filteredPic[self.adjustYoffset(y1):self.adjustYoffset(y2), x1 : x2]
            res = cv.matchTemplate(roi ,temp, eval('cv.TM_CCOEFF_NORMED')) #cv.TM_CCOEFF_NORMED
            loc = np.where( res >= threshold)

            if np.amax(res) > threshold:
                if ptsneeded:
                    for pt in zip(*loc[::-1]):
                        self.matchCoords.setPoints(pt[0], pt[1])
                
                return True
            
        return False
    

    def checkForPopups(self): #get ss, grab ea region of interest and scan for any of those.
        screen = self.returnColorSS(False).copy()
        roiRevive   = screen[self.adjustYoffset(345):self.adjustYoffset(445), 200:391] #345, 445, 200, 391,0.85):
        roiMapleView = screen[self.adjustYoffset(49):self.adjustYoffset(80), 793:909] #49,80,793,909
        roiRandAds = screen[self.adjustYoffset(11):self.adjustYoffset(120), 750:900]
        roiNewConfirm = screen[self.adjustYoffset(365):self.adjustYoffset(455), 346:615]
        roiVioletta = screen[self.adjustYoffset(110):self.adjustYoffset(420),228:763]
        roiNewForced = screen[self.adjustYoffset(90):self.adjustYoffset(120), 20:345] #297-323 90-120

        resRev = cv.matchTemplate(roiRevive, self.templateDict['revivebtn'], eval('cv.TM_CCOEFF_NORMED'))
        resMapleView = cv.matchTemplate(roiMapleView, self.templateDict['mapleviewpopup'], eval('cv.TM_CCOEFF_NORMED'))
        resAds1 = cv.matchTemplate(roiRandAds ,self.templateDict['exitpic'], eval('cv.TM_CCOEFF_NORMED'))
        resAds2 = cv.matchTemplate(roiRandAds ,self.templateDict['exitpic2'], eval('cv.TM_CCOEFF_NORMED'))
        resAds3 = cv.matchTemplate(roiRandAds ,self.templateDict['newmenuexit'], eval('cv.TM_CCOEFF_NORMED'))
        resAds4 = cv.matchTemplate(roiRandAds ,self.templateDict['adexit3'], eval('cv.TM_CCOEFF_NORMED'))
        resNewConfirm = cv.matchTemplate(roiNewConfirm ,self.templateDict['newcontentconfirm'], eval('cv.TM_CCOEFF_NORMED'))
        resVioletta = cv.matchTemplate(roiVioletta ,self.templateDict['violettabotpopup'], eval('cv.TM_CCOEFF_NORMED'))
        resNewForced = cv.matchTemplate(roiNewForced ,self.templateDict['newtuticon'], eval('cv.TM_CCOEFF_NORMED'))
              


        threshold = 0.8
        if np.amax(resRev) > threshold:
            self.gameState.updateStatus(stateConstants.S20_isdead, True)
            print("we dead")
        
        elif (np.amax(resAds1) > threshold or np.amax(resAds2) > threshold or np.amax(resAds3) > threshold or np.amax(resAds4) > threshold) and \
            (not self.gameState.currState[stateConstants.S24_in_dialog] and not self.gameState.currState[stateConstants.S27_in_bag] and not self.gameState.currState[stateConstants.S28_in_mailbox]):
            if np.amax(resAds1) > threshold:
                res = resAds1 
            elif np.amax(resAds2) > threshold:
                res = resAds2
            elif np.amax(resAds3) > threshold:
                res = resAds3
            else:
                res = resAds4
            loc = np.where( res >= threshold)
            for pt in zip(*loc[::-1]):
                self.matchCoords.setPoints(pt[0], pt[1])   
           # print(self.matchCoords.xyLoc[0])
           # print(self.matchCoords.xyLoc[1])
            #cv.imwrite("roi3.png", roiRandAds)
            print("popup visible")
            self.gameState.updateStatus(stateConstants.S22_popup_visible, True)
        elif np.amax(resNewForced) > threshold: #and self.gameState.buttonPressed:
            self.gameState.updateStatus(stateConstants.S30_new_forced_visible, True)
            print("new forced tut visible")
        elif np.amax(resMapleView) > threshold:
            self.gameState.updateStatus(stateConstants.S32_mapleview_visible, True)
            print("WEE WOO WEE WOO NOT GOOD")
            
        elif np.amax(resVioletta) > threshold:
            self.gameState.updateStatus(stateConstants.S30_new_forced_visible, True)
            print("VIOLETTA DETECTED")
        
        if self.gameState.detected() != -1:
            self.popupDetected = True
        else:
            self.popupDetected = False

        return screen