import BotTools

BotTools.cBotTools.getTemplate(35, 75, 100, 185, True)